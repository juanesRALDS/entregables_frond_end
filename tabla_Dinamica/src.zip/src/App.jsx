import Table from "./component/Table" 

function App() {


  return (
    <>
    <Table/>
    </>
  )
}

export default App
